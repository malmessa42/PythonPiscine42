def count_in_list(lst, value):
    """
    Count occurrences of value in lst.
    """
    return lst.count(value)


def sum_numbers(lst):
    """
    Returns the summation value
    """
    return sum(lst)
